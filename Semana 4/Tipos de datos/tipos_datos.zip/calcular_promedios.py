'''Dada `n` cantidad de notas de un estudiante, calcular:
1. Cuantas notas tiene aprobadas (mayor a 70).
2. Cuantas notas tiene desaprobadas (menor a 70).
3. El promedio de todas.
4. El promedio de las aprobadas.
5. El promedio de las desaprobadas.'''

cant_notas = int(input('Ingrese la cantidad de notas que va a revisar: '))

contador = 1
notas = 0
cant_nota_aprobada = 0
cant_nota_desaprobada = 0
promedio_aprobadas = 0
promedio_desaprobadas = 0
promedio_total = 0



while(contador <= cant_notas):
    nota = int(input(f'Por favor ingrese la nota {contador}: '))

    if(nota >= 70):
        cant_nota_aprobada = cant_nota_aprobada + 1
        promedio_aprobadas = promedio_aprobadas + nota 
            
    else:
        cant_nota_desaprobada = cant_nota_desaprobada + 1
        promedio_desaprobadas = promedio_desaprobadas + nota 
            

    promedio_total = promedio_total + nota
    promedio_total = promedio_total / cant_notas

    if(cant_nota_aprobada>=1):
        promedio_aprobadas = promedio_aprobadas / cant_nota_aprobada
    elif(cant_nota_aprobada>=1 & cant_nota_desaprobada>=1 ):
        promedio_aprobadas = promedio_aprobadas / cant_nota_aprobada
        promedio_desaprobadas = promedio_desaprobadas / cant_nota_desaprobada 
    elif(cant_nota_desaprobada>=1 ):
        promedio_desaprobadas = promedio_desaprobadas / cant_nota_desaprobada
    contador = contador + 1
print(f'El promedio total es: {promedio_total}')
print(f'Las promedio aprobadas son: {promedio_aprobadas} y las promedio desaprobadas son: {promedio_desaprobadas}')
print(f'Las notas aprobadas son: {cant_nota_aprobada} y las notas desaprobadas son: {cant_nota_desaprobada}')
