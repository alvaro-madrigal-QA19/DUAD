'''Cree un programa que le pida tres números al usuario y muestre el mayor.'''


#num = int(input('Ingrese un número'))


contador = 1

while(contador <= 3):
    num = int(input('Ingrese otro número: '))
    max = num
    if(num > max):
        max = num        
    else:
        contador = contador + 1  
else:
    print(f'El número mayor es: {max}')
