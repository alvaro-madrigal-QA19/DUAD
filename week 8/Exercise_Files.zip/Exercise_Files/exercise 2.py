'''2. Lea sobre el resto de métodos de la clase File de Python [aquí](https://www.w3schools.com/python/python_ref_file.asp) 
y cree una tabla donde explique qué hace cada uno. **No necesita usar código para esto, es solo crear una tabla en Notion o Word.**
    1. Siga el siguiente formato:
        
        
        | Método | Descripción |
        | --- | --- |
        | `read()` | Lee y retorna todo el contenido del archivo |
        | `readlines()` | Lee todo el contenido del archivo y retorna una lista con cada línea. |
        | `write()` | Escribe contenidos en un archivo. |'''